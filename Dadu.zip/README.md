Note that this project is not for professional programmer or who has experience in flutter.
I just created this project to sharpen flutter and dart skills
<br>
<a href="https://www.youtube.com/channel/UCp3aWVhAq3zulDXrx2lUUHQ?view_as=subscriber" > Visit the creator on YouTube </a>
